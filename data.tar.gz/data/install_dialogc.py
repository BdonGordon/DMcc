#!/usr/bin/python

print "Installation Script of Dialogc"
next = raw_input("Press ENTER key to proceed")
print ""